//#ifndef __WAVE_H
//#define __WAVE_H

//void HC_SR04_Init(void);
//int16_t sonar_mm(void);
//float sonar(void);

//#endif
